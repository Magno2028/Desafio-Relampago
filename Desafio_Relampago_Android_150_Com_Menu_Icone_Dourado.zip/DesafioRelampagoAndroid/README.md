# Desafio Relâmpago

Aplicativo Android do quiz Desafio Relâmpago.

- 50 perguntas
- 10 perguntas por partida
- 13 segundos por pergunta
- 3 vidas
- distribuição equilibrada das posições das respostas corretas
- bolsa persistente de perguntas para evitar repetição até usar as 50

O conteúdo do quiz fica em `app/src/main/assets/index.html`.

## Ícone do aplicativo
O projeto usa como ícone oficial a imagem dourada enviada para o projeto, instalada em todas as densidades Android (mdpi a xxxhdpi) como `ic_launcher.png`.
