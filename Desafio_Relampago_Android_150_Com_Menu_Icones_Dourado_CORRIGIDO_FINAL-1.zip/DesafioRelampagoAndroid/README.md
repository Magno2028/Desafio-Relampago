# Desafio Relâmpago

Aplicativo Android do quiz Desafio Relâmpago.

- 150 perguntas em 5 níveis
- 10 perguntas por partida
- 13 segundos por pergunta; publicidade de 8 segundos após a 5ª pergunta
- 3 vidas
- distribuição equilibrada das posições das respostas corretas
- bolsa de perguntas para evitar repetição durante as partidas
- espaço reservado para publicidade exibido após a 5ª pergunta, quando o jogador ainda possui vidas

## Correção da versão 1.0.2

A lógica da pausa publicitária passou a usar um contador explícito de perguntas respondidas. Isso garante que o ponto de inserção da publicidade seja definido pela **5ª pergunta respondida**, independentemente do índice interno do banco de perguntas.

O conteúdo do quiz fica em `app/src/main/assets/index.html`.

## Ícone do aplicativo
O projeto usa como ícone oficial a imagem dourada enviada para o projeto, instalada em todas as densidades Android (mdpi a xxxhdpi) como `ic_launcher.png`.


Correção: seleção das perguntas usa estado v3 por texto, impedindo repetição dentro da partida e evitando estados antigos do aplicativo. O nível Muito Fácil utiliza exclusivamente seu banco de 30 perguntas.
