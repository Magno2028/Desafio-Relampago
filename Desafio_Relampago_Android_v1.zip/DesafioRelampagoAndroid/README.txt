DESAFIO RELÂMPAGO - PROJETO ANDROID

Este projeto transforma a versão 3.0 do jogo HTML em um app Android.
Ele usa WebView para executar o jogo e o Google Mobile Ads SDK para o intersticial.

IMPORTANTE:
- O projeto usa o ID de anúncio de TESTE do Google durante o desenvolvimento.
- O ID real criado na AdMob está guardado apenas no código como referência e NÃO é usado enquanto testamos.
- Nunca clique em anúncios reais durante os testes.
- O app usa targetSdk 36, adequado ao requisito atual do Google Play para novos apps a partir de 31/08/2026.

O workflow do GitHub Actions gera um APK de teste automaticamente.
